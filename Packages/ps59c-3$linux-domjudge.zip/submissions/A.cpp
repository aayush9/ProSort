#include <bits/stdc++.h>
using namespace std;
int main(){
    long double n,k,run=1.0,ans;
    cin>>n>>k;
    ans = k/(n+1);
    for(int i=2;;++i){
        run*=(n-k+i)/(n+i);
        if(ans<run*i*k/(n+1)) ans = run*i*k/(n+1);
        else break;
    }
    cout<<fixed<<setprecision(8)<<ans;
}
