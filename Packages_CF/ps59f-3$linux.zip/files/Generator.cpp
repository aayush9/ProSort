#include <bits/stdc++.h>
#include "testlib.h"
using namespace std;

set<pair<int,int>> edges;

int main(int argc, char* argv[]){
	registerGen(argc,argv,1);
	int n=rnd.next(1,100000);
	int k=rnd.next(1,100000);
	cout<<n<<' '<<k<<endl;
}
