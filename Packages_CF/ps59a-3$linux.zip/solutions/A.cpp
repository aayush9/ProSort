#include <bits/stdc++.h>
using namespace std;
int main(){
	int T,p,q;
	for(cin>>T;T--;cout<<p/q<<' '<<p%q<<" "<<q<<endl)
		cin>>p>>q;
}
